============
ArcherHelper
============
Author: Moonwesowthirsdr

-----------
Description
-----------
This is a mod of the game "Blade and Sorcery". The basic idea of this mod is to spawn an indicator to mark the position where the object hit, so the player can tell where the arrow/objects hit even it is far away.
Since ".dll" file has been used in this mod, you need to use the "Mod Loader" to load this mod. Mod Loader link: http://treesoft.dk/bas/modloader/ . 

---------
User Case
---------
Make sure to put the setting file "AHSetting.json" in the path of "(root)/Mods/ArcherHelper/".
In the file "AHSetting.json", adjust the parameters as you like:
1. ObjectToIndiNames(List<string>): Put all the gameobject names that are wanted to spawn the inidcator in this list. Put another name with the "(Clone)" postfix for each object to ensure every situation is included. The gameobject name for the arrow is "Pool_Arrow1".
2. SearchPlayerTime(float): Time interval to search the player. Suggested as 2.0 seconds. This process hurt performance so it should not be too small.
3. CheckHandTime(float): Time interval to check whether the listed object is in the player's hand. Suggested as 0.1 second.
4. UseRightHand(bool): Active the mod when use the right hand grab.
5. UseLeftHand(bool): Active the mod when use the left hand grab.
6. TimeExistAfterHand(float): How long the object will wait for collision after leaving the hand. Note that when you pull a bow with an arrow in your hand, the arrow will still treat as left your hand even it's not seems so.
7. OriginalSize(Vector3): The indicators oringinal size. Suggested as (0.02,0.02,0.02) if UseDynamicSize is true.
8. UseDynamicSize(bool): If true, the indicator will get larger as it gets farther away from the player.
9. IndicatorColor(Color): Indicator color, red as (1.0,0.0,0.0,alpha).
10.IndicatorDespawnTime(float): How long will the indicators stay in the game. Suggested as 2.0 seconds.

In Game: Whenever an object, whose name is in the ObjectToIndiNames list, is grabbed, the mod will be activated. After it leaves the player's hand and hits something, the mod will spawn an indicator at that position, which is an easy way to see where the object collided.

